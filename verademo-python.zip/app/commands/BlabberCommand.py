class BlabberCommand:
    def execute(self, blabberUsername):
        pass